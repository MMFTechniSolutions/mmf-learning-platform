import React from 'react';
import MMFLearningPlatform from './mmf-learning-platform';
import './App.css';

function App() {
  return (
    <div className="App">
      <MMFLearningPlatform />
    </div>
  );
}

export default App;
