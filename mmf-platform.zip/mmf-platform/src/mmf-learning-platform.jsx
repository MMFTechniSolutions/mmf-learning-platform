import React, { useState, useEffect } from 'react';
import { Download, Plus, Trash2, Eye, EyeOff, RotateCcw } from 'lucide-react';

const MMFLearningPlatform = () => {
  const [userRole, setUserRole] = useState(null);
  const [formatorCode, setFormatorCode] = useState('');
  const [formatorInputCode, setFormatorInputCode] = useState('');
  const [learnerData, setLearnerData] = useState(null);
  const [learners, setLearners] = useState([]);
  const [currentClass, setCurrentClass] = useState('1');
  const [currentModule, setCurrentModule] = useState(0);
  const [quizAnswers, setQuizAnswers] = useState({});
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [moduleProgress, setModuleProgress] = useState({});

  // Classes structure
  const classes = {
    '1': {
      name: 'Classe 1 - Production d\'Énergie',
      modules: [
        { id: 1, name: 'Santé, Sécurité & Environnement', videoUrl: '', description: 'À remplir' },
        { id: 2, name: 'Mise en Service des Installations', videoUrl: '', description: 'À remplir' },
        { id: 3, name: 'Contrôle des Paramètres', videoUrl: '', description: 'À remplir' },
        { id: 4, name: 'Mise Hors Service', videoUrl: '', description: 'À remplir' },
        { id: 5, name: 'Gestion de la Maintenance', videoUrl: '', description: 'À remplir' }
      ]
    },
    '2': {
      name: 'Classe 2 - Production d\'Énergie Avancée',
      modules: [
        { id: 1, name: 'Module 1', videoUrl: '', description: 'À remplir' },
        { id: 2, name: 'Module 2', videoUrl: '', description: 'À remplir' },
        { id: 3, name: 'Module 3', videoUrl: '', description: 'À remplir' }
      ]
    },
    '3': {
      name: 'Classe 3 - Production d\'Énergie Intermédiaire',
      modules: [
        { id: 1, name: 'Module 1', videoUrl: '', description: 'À remplir' },
        { id: 2, name: 'Module 2', videoUrl: '', description: 'À remplir' },
        { id: 3, name: 'Module 3', videoUrl: '', description: 'À remplir' }
      ]
    },
    '4': {
      name: 'Classe 4 - Production d\'Énergie Base',
      modules: [
        { id: 1, name: 'Santé, Sécurité & Environnement', videoUrl: '', description: 'À remplir' },
        { id: 2, name: 'Mise en Service des Installations', videoUrl: '', description: 'À remplir' },
        { id: 3, name: 'Contrôle des Paramètres', videoUrl: '', description: 'À remplir' },
        { id: 4, name: 'Mise Hors Service', videoUrl: '', description: 'À remplir' },
        { id: 5, name: 'Gestion de la Maintenance', videoUrl: '', description: 'À remplir' }
      ]
    },
    'A': {
      name: 'Classe A - Appareils Frigorifiques',
      modules: [
        { id: 1, name: 'Santé, Sécurité & Environnement', videoUrl: '', description: 'À remplir' },
        { id: 2, name: 'Mise en Service Frigorifique', videoUrl: '', description: 'À remplir' },
        { id: 3, name: 'Contrôle des Paramètres Frigorifiques', videoUrl: '', description: 'À remplir' },
        { id: 4, name: 'Mise Hors Service Frigorifique', videoUrl: '', description: 'À remplir' },
        { id: 5, name: 'Gestion de la Maintenance', videoUrl: '', description: 'À remplir' }
      ]
    },
    'B': {
      name: 'Classe B - Appareils Frigorifiques Simplifié',
      modules: [
        { id: 1, name: 'Module 1', videoUrl: '', description: 'À remplir' },
        { id: 2, name: 'Module 2', videoUrl: '', description: 'À remplir' },
        { id: 3, name: 'Module 3', videoUrl: '', description: 'À remplir' }
      ]
    }
  };

  // Quiz template (20 questions)
  const quizTemplate = Array(20).fill(null).map((_, i) => ({
    id: i + 1,
    question: `Question ${i + 1} - À remplir`,
    options: ['Option A', 'Option B', 'Option C', 'Option D'],
    correctAnswer: 0
  }));

  // Générer ID aléatoire apprenant
  const generateLearnerId = () => {
    return 'APP-' + Math.random().toString(36).substr(2, 9).toUpperCase();
  };

  // Initialiser apprenant
  const initializeLearner = () => {
    const newLearner = {
      id: generateLearnerId(),
      createdAt: new Date().toLocaleString(),
      classProgress: {},
      sessions: 0
    };
    classes && Object.keys(classes).forEach(cls => {
      newLearner.classProgress[cls] = {
        modules: {}
      };
      classes[cls].modules.forEach(mod => {
        newLearner.classProgress[cls].modules[mod.id] = {
          completed: false,
          quizScore: 0
        };
      });
    });
    setLearnerData(newLearner);
    setCurrentClass('1');
    setCurrentModule(0);
  };

  // Soumettre quiz
  const submitQuiz = () => {
    let score = 0;
    quizTemplate.forEach((q, idx) => {
      if (quizAnswers[idx] === q.correctAnswer) score++;
    });
    const percentage = (score / quizTemplate.length) * 100;
    
    const updatedLearner = { ...learnerData };
    updatedLearner.classProgress[currentClass].modules[
      classes[currentClass].modules[currentModule].id
    ] = {
      completed: true,
      quizScore: percentage
    };
    setLearnerData(updatedLearner);
    setQuizSubmitted(true);
  };

  // Reset quiz
  const resetQuiz = () => {
    setQuizAnswers({});
    setQuizSubmitted(false);
  };

  // Ajouter apprenant au tableau formateur
  const addLearnerToFormator = () => {
    if (learnerData) {
      setLearners([...learners, { ...learnerData, addedAt: new Date().toLocaleString() }]);
      setLearnerData(null);
      setUserRole(null);
    }
  };

  // Supprimer apprenant
  const removeLearner = (id) => {
    setLearners(learners.filter(l => l.id !== id));
  };

  // Export Excel
  const exportToExcel = () => {
    let csvContent = 'ID Apprenant,Date Création,Classe,Module,Score,Complété,Ajouté le\n';
    learners.forEach(learner => {
      Object.entries(learner.classProgress).forEach(([cls, data]) => {
        Object.entries(data.modules).forEach(([modId, modData]) => {
          const moduleName = classes[cls].modules.find(m => m.id == modId)?.name || '';
          csvContent += `${learner.id},${learner.createdAt},${cls},${moduleName},${modData.quizScore || 0}%,${modData.completed ? 'Oui' : 'Non'},${learner.addedAt || 'N/A'}\n`;
        });
      });
    });

    const link = document.createElement('a');
    link.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csvContent);
    link.download = `apprenants_mmf_${new Date().getTime()}.csv`;
    link.click();
  };

  // LOGIN FORMATEUR
  if (!userRole) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-900 to-blue-700 flex items-center justify-center p-4">
        <div className="bg-white rounded-lg shadow-2xl p-8 max-w-md w-full">
          <h1 className="text-3xl font-bold text-blue-900 mb-2">MMF Révision</h1>
          <p className="text-gray-600 mb-6">Plateforme de Suivi Interactif</p>
          
          <div className="space-y-4">
            <button
              onClick={() => {
                setFormatorCode('SAE2024');
                setUserRole('learner');
                initializeLearner();
              }}
              className="w-full bg-green-500 hover:bg-green-600 text-white py-3 rounded-lg font-semibold transition"
            >
              Mode Apprenant
            </button>

            <div className="border-t my-4"></div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Code Formateur
              </label>
              <input
                type="password"
                value={formatorInputCode}
                onChange={(e) => setFormatorInputCode(e.target.value)}
                placeholder="Entrez le code"
                className="w-full border border-gray-300 rounded-lg px-4 py-2 mb-3"
              />
              <button
                onClick={() => {
                  if (formatorInputCode === 'SAE2024') {
                    setUserRole('formator');
                  } else {
                    alert('Code invalide');
                  }
                }}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg font-semibold transition"
              >
                Accès Formateur
              </button>
              <p className="text-xs text-gray-500 mt-2">Code: SAE2024</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // MODE APPRENANT
  if (userRole === 'learner' && learnerData) {
    const moduleActuel = classes[currentClass].modules[currentModule];
    const moduleData = learnerData.classProgress[currentClass].modules[moduleActuel.id];
    
    return (
      <div className="min-h-screen bg-gray-100">
        {/* En-tête */}
        <div className="bg-blue-900 text-white p-4">
          <div className="max-w-6xl mx-auto flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold">MMF Révision</h1>
              <p className="text-blue-200">ID: {learnerData.id}</p>
            </div>
            <button
              onClick={() => {
                addLearnerToFormator();
              }}
              className="bg-green-500 hover:bg-green-600 px-4 py-2 rounded-lg font-semibold transition"
            >
              Terminer Parcours
            </button>
          </div>
        </div>

        <div className="max-w-6xl mx-auto p-4 grid grid-cols-1 lg:grid-cols-4 gap-4">
          {/* Sidebar Navigation */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow p-4">
              <h3 className="font-bold text-gray-900 mb-3">Parcours</h3>
              <div className="space-y-2">
                {Object.entries(classes).map(([classKey, classData]) => (
                  <button
                    key={classKey}
                    onClick={() => {
                      setCurrentClass(classKey);
                      setCurrentModule(0);
                      setQuizSubmitted(false);
                      setQuizAnswers({});
                    }}
                    className={`w-full text-left px-3 py-2 rounded-lg transition ${
                      currentClass === classKey
                        ? 'bg-blue-500 text-white'
                        : 'bg-gray-100 hover:bg-gray-200'
                    }`}
                  >
                    <div className="text-sm font-semibold">{classKey}</div>
                    <div className="text-xs opacity-75">
                      {Object.values(learnerData.classProgress[classKey].modules).filter(m => m.completed).length}/
                      {classes[classKey].modules.length}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Modules */}
            <div className="bg-white rounded-lg shadow p-4 mt-4">
              <h3 className="font-bold text-gray-900 mb-3">Modules</h3>
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {classes[currentClass].modules.map((mod, idx) => {
                  const modData = learnerData.classProgress[currentClass].modules[mod.id];
                  return (
                    <button
                      key={mod.id}
                      onClick={() => {
                        setCurrentModule(idx);
                        setQuizSubmitted(false);
                        setQuizAnswers({});
                      }}
                      className={`w-full text-left px-3 py-2 rounded-lg transition text-sm ${
                        currentModule === idx
                          ? 'bg-blue-500 text-white'
                          : modData.completed
                          ? 'bg-green-100 border-l-4 border-green-500'
                          : 'bg-gray-100 hover:bg-gray-200'
                      }`}
                    >
                      <div className="font-semibold">{mod.name}</div>
                      {modData.completed && (
                        <div className="text-xs">Score: {modData.quizScore}%</div>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Contenu Principal */}
          <div className="lg:col-span-3">
            <div className="bg-white rounded-lg shadow p-6">
              {/* Info Module */}
              <div className="mb-6">
                <h2 className="text-2xl font-bold text-gray-900">{classes[currentClass].name}</h2>
                <h3 className="text-xl text-blue-600 mt-2">{moduleActuel.name}</h3>
                <p className="text-gray-600 mt-2">Module {currentModule + 1}/{classes[currentClass].modules.length}</p>
              </div>

              {/* Zone vidéo/images */}
              <div className="bg-gray-100 rounded-lg p-8 mb-6 text-center">
                {moduleActuel.videoUrl ? (
                  <iframe
                    width="100%"
                    height="400"
                    src={moduleActuel.videoUrl.replace('watch?v=', 'embed/')}
                    frameBorder="0"
                    allowFullScreen
                  ></iframe>
                ) : (
                  <div className="text-gray-400">
                    <p className="text-lg">Vidéo à venir</p>
                    <p className="text-sm">Lien YouTube ou Vimeo</p>
                  </div>
                )}
              </div>

              {/* Description */}
              <div className="bg-blue-50 p-4 rounded-lg mb-6">
                <h4 className="font-semibold text-gray-900">Description</h4>
                <p className="text-gray-700 mt-2">{moduleActuel.description}</p>
                <div className="mt-4 p-3 bg-white rounded border-l-4 border-blue-500 text-sm text-gray-600">
                  <strong>Source:</strong> À ajouter par le formateur
                </div>
              </div>

              {/* Quiz */}
              <div className="border-t pt-6">
                <h4 className="text-lg font-bold text-gray-900 mb-4">Quiz du Module (20 questions)</h4>
                
                {quizSubmitted ? (
                  <div className="bg-green-50 p-6 rounded-lg">
                    <div className="text-center mb-4">
                      <div className="text-5xl font-bold text-green-600">
                        {moduleData.quizScore.toFixed(1)}%
                      </div>
                      <p className="text-gray-700 mt-2">Module complété!</p>
                    </div>
                    <button
                      onClick={resetQuiz}
                      className="w-full bg-blue-500 hover:bg-blue-600 text-white py-2 rounded-lg font-semibold transition mt-4"
                    >
                      Refaire le Quiz
                    </button>
                  </div>
                ) : (
                  <div className="space-y-4 max-h-96 overflow-y-auto">
                    {quizTemplate.map((q, idx) => (
                      <div key={idx} className="border rounded-lg p-4">
                        <p className="font-semibold text-gray-900 mb-3">{q.question}</p>
                        <div className="space-y-2">
                          {q.options.map((opt, optIdx) => (
                            <label key={optIdx} className="flex items-center cursor-pointer">
                              <input
                                type="radio"
                                name={`q-${idx}`}
                                checked={quizAnswers[idx] === optIdx}
                                onChange={() => {
                                  setQuizAnswers({ ...quizAnswers, [idx]: optIdx });
                                }}
                                className="mr-3"
                              />
                              <span className="text-gray-700">{opt}</span>
                            </label>
                          ))}
                        </div>
                      </div>
                    ))}
                    <button
                      onClick={submitQuiz}
                      className="w-full bg-green-500 hover:bg-green-600 text-white py-3 rounded-lg font-bold transition mt-4"
                    >
                      Soumettre le Quiz
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // MODE FORMATEUR
  if (userRole === 'formator') {
    return (
      <div className="min-h-screen bg-gray-100">
        {/* En-tête */}
        <div className="bg-blue-900 text-white p-4">
          <div className="max-w-7xl mx-auto flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold">Tableau de Bord Formateur</h1>
              <p className="text-blue-200">Suivi des Apprenants MMF</p>
            </div>
            <div className="space-x-2">
              <button
                onClick={exportToExcel}
                className="bg-green-500 hover:bg-green-600 px-4 py-2 rounded-lg font-semibold transition inline-flex items-center gap-2"
              >
                <Download size={20} />
                Export Excel
              </button>
              <button
                onClick={() => setUserRole(null)}
                className="bg-red-500 hover:bg-red-600 px-4 py-2 rounded-lg font-semibold transition"
              >
                Déconnexion
              </button>
            </div>
          </div>
        </div>

        <div className="max-w-7xl mx-auto p-4">
          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="text-gray-600 text-sm font-semibold">Apprenants Actifs</h3>
              <p className="text-4xl font-bold text-blue-600 mt-2">{learners.length}</p>
            </div>
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="text-gray-600 text-sm font-semibold">Modules Complétés</h3>
              <p className="text-4xl font-bold text-green-600 mt-2">
                {learners.reduce((sum, l) => 
                  sum + Object.values(l.classProgress).reduce((s, c) => 
                    s + Object.values(c.modules).filter(m => m.completed).length, 0), 0)
                }
              </p>
            </div>
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="text-gray-600 text-sm font-semibold">Taux de Complétion Moy.</h3>
              <p className="text-4xl font-bold text-orange-600 mt-2">
                {learners.length > 0 ? (
                  (learners.reduce((sum, l) => {
                    const total = Object.values(l.classProgress).reduce((s, c) => 
                      s + Object.values(c.modules).length, 0);
                    const completed = Object.values(l.classProgress).reduce((s, c) => 
                      s + Object.values(c.modules).filter(m => m.completed).length, 0);
                    return sum + (completed / (total || 1));
                  }, 0) / learners.length * 100).toFixed(1)
                ) : 0}%
              </p>
            </div>
          </div>

          {/* Tableau Apprenants */}
          <div className="bg-white rounded-lg shadow overflow-hidden">
            <div className="p-6 border-b">
              <h2 className="text-xl font-bold text-gray-900">Apprenants en Cours</h2>
            </div>
            
            {learners.length === 0 ? (
              <div className="p-6 text-center text-gray-500">
                Aucun apprenant pour le moment
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 border-b">
                    <tr>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">ID Apprenant</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Date Création</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Progression</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Score Moyen</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {learners.map((learner) => {
                      const totalMods = Object.values(learner.classProgress).reduce((s, c) => 
                        s + Object.values(c.modules).length, 0);
                      const completedMods = Object.values(learner.classProgress).reduce((s, c) => 
                        s + Object.values(c.modules).filter(m => m.completed).length, 0);
                      const avgScore = Object.values(learner.classProgress).reduce((s, c) => 
                        s + Object.values(c.modules).reduce((ss, m) => ss + (m.quizScore || 0), 0), 0) / 
                        (totalMods || 1);

                      return (
                        <tr key={learner.id} className="border-b hover:bg-gray-50">
                          <td className="px-6 py-4 text-sm font-mono text-gray-900">{learner.id}</td>
                          <td className="px-6 py-4 text-sm text-gray-600">{learner.createdAt}</td>
                          <td className="px-6 py-4 text-sm text-gray-900">
                            <div className="w-32 bg-gray-200 rounded-full h-2">
                              <div
                                className="bg-blue-600 h-2 rounded-full"
                                style={{ width: `${(completedMods / (totalMods || 1)) * 100}%` }}
                              ></div>
                            </div>
                            <span className="text-xs text-gray-600 mt-1 block">
                              {completedMods}/{totalMods}
                            </span>
                          </td>
                          <td className="px-6 py-4 text-sm font-bold text-gray-900">
                            {avgScore.toFixed(1)}%
                          </td>
                          <td className="px-6 py-4 text-sm">
                            <button
                              onClick={() => removeLearner(learner.id)}
                              className="text-red-600 hover:text-red-800 transition"
                            >
                              <Trash2 size={18} />
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }
};

export default MMFLearningPlatform;
