# 🏗️ Plateforme MMF - Mécanique des Machines Fixes

**Outil interactif de suivi de révision** pour la préparation aux examens de qualification en Mécanique des Machines Fixes au Québec.

## ✨ Fonctionnalités

### Mode Apprenant
- 🆔 **ID aléatoire** généré automatiquement
- 📚 **6 classes** (1, 2, 3, 4, A, B)
- 📖 **Modules structurés** par classe
- 🧪 **Quiz 20 questions** par module
- 📊 **Suivi de progression** en temps réel
- 🎯 **Routes d'apprentissage** 30-60 jours

### Mode Formateur
- 📋 **Tableau de bord** avec suivi de tous les apprenants
- 📈 **Statistiques globales** (progression, scores moyens)
- 💾 **Export Excel/CSV** automatisé
- 🔐 **Accès sécurisé** par code formateur
- 🗑️ **Gestion des sessions** d'apprenants

## 🚀 Installation

### Prérequis
- Node.js 14+ 
- npm ou yarn
- Compte Vercel (optionnel pour déploiement)

### Étapes locales
```bash
git clone https://github.com/YOUR_USERNAME/mmf-learning-platform.git
cd mmf-learning-platform
npm install
npm start
```

Le site s'ouvrira sur `http://localhost:3000`

## 🌍 Déploiement sur Vercel

1. Connectez votre repo GitHub à Vercel
2. Vercel détectera automatiquement la configuration React
3. Cliquez sur **Deploy**
4. Votre site sera live en ~2 minutes !

## 🔐 Codes d'accès

### Mode Apprenant
- Pas de code requis
- Cliquez sur "Mode Apprenant"

### Mode Formateur
- **Code par défaut** : `SAE2024`
- ⚠️ **À CHANGER** après première connexion

## 📝 Personnalisation

### Ajouter du contenu (Vidéos, Images, Quiz)

1. Modifiez `mmf-learning-platform.jsx`
2. Dans la structure `classes`, complétez :
   - `videoUrl` : Lien YouTube
   - `description` : Votre texte
3. Modifiez `quizTemplate` avec vos questions

### Exemple :
```javascript
'1': {
  name: 'Classe 1',
  modules: [
    { 
      id: 1, 
      name: 'Module 1',
      videoUrl: 'https://youtube.com/watch?v=...', // ← Ajouter
      description: 'Votre texte ici' // ← Remplir
    }
  ]
}
```

## 📊 Export des données

1. Connectez-vous en **Mode Formateur**
2. Cliquez sur **"Export Excel"**
3. Un fichier CSV sera téléchargé avec :
   - ID apprenant
   - Date de création
   - Progression par classe/module
   - Scores des quiz
   - Statut de complétion

## 🎯 Flux utilisateur

**Apprenant:**
1. Accueil → Mode Apprenant
2. ID aléatoire généré automatiquement
3. Sélectionner une classe
4. Suivre les modules dans l'ordre
5. Compléter quiz (20 questions)
6. Voir les scores
7. Cliquer "Terminer Parcours" pour envoyer au formateur

**Formateur:**
1. Accueil → Code: SAE2024
2. Voir tous les apprenants
3. Progression en temps réel
4. Statistiques globales
5. Export Excel des résultats

## 📱 Responsive Design

✅ Fonctionne sur :
- 💻 Desktop
- 📱 Tablette
- 📲 Mobile

## 🔒 Sécurité

- Pas de base de données externe
- Données stockées en session navigateur
- Code formateur configurable
- Pas de cookies non-essentiels

## 🛠️ Support

Pour toute question :
1. Vérifiez que tous les fichiers sont présents
2. Testez en mode développement : `npm start`
3. Consultez les erreurs dans la console du navigateur

## 📄 Licence

Libre d'utilisation pour la formation MMF au Québec.

---

**Version**: 1.0.0  
**Dernière mise à jour**: 2024
